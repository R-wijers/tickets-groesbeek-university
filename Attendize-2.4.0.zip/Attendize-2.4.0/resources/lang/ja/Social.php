<?php

return array(
    //============================== New strings to translate ==============================//
    // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\OrganiserSocialSection.blade.php
    'pinterest'              => 'Pinterest',
    //==================================== Translations ====================================//
    'email'                  => 'Email',
    'facebook'               => 'Facebook',
    'linkedin'               => 'LinkedIn',
    'share_buttons_to_show'  => '表示する共有ボタン',
    'social_settings'        => 'ソーシャル設定',
    'social_share_text'      => 'ソーシャルシェアテキスト',
    'social_share_text_help' => 'これは、ユーザーがソーシャルネットワークであなたのイベントを共有するときにデフォルトで共有されるテキストです。',
    'twitter'                => 'Twitter',
    'whatsapp'               => 'WhatsApp',
);