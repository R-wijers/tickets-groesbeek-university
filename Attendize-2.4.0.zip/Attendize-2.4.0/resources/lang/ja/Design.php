<?php

return array(
    //============================== New strings to translate ==============================//
    'event_page_preview'              => 'イベントページのプレビュー',
    //==================================== Translations ====================================//
    'background_options'              => '背景オプション',
    'images_provided_by_pixabay'      => 'Images Provided By <b>PixaBay.com</b>',
    'select_from_available_images'    => '利用可能な画像から選択',
    'use_a_colour_for_the_background' => '背景色を使う',
);