<?php
return [
    'received_new_order'             => 'Es ging eine neue Bestllung für die Veranstaltung ein',
    'order_still_awaiting_payment'   => 'Achtung: Bezahlung ausstehend.',
    'manage_order'                   => 'Du kannst die Bestellung hier verwalten',
    'successful_order'               => 'Deine Bestellung für die Veranstaltung <strong>:name</strong> war erfolgreich.',
    'tickets_attached'               => 'Deine Tickets sind dieser E-Mail beigefügt. Hier kannst Deine Bestellung ansehen und Deine Tickets herunterladen:',
];
