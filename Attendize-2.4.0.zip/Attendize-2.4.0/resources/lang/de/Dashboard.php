<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 18:57:21
*************************************************************************/

return array (
    //============================== New strings to translate ==============================//
    'this_event_has_started' => 'Diese Veranstaltung hat begonnen.',
    //==================================== Translations ====================================//
    'create_tickets' => 'Tickets erstellen',
    'edit_event_page_design' => 'Design der Veranstaltungsseite  bearbeiten',
    'edit_organiser_fees' => 'Veranstaltergebühren bearbeiten',
    'event_page_visits' => 'Eventseitenbesucher',
    'event_url' => 'URL zur Veranstaltung',
    'event_views' => 'Views der Veranstaltung',
    'generate_affiliate_link' => 'Affiliate link erstellen',
    'orders' => 'Bestellungen',
    'quick_links' => 'Quick Links',
    'registrations_by_ticket' => 'Regestrierungen per Ticket',
    'sales_volume' => 'Anzahl Verkäufe',
    'share_event' => 'Veranstaltung teilen',
    'this_event_is_on_now' => 'Diese Veranstaltung findet gerade statt',
    'ticket_sales_volume' => 'Anzahl Ticketverkäufe',
    'tickets_sold' => 'Tickets verkauft',
    'website_embed_code' => 'Embed Code für Webseite',
);
