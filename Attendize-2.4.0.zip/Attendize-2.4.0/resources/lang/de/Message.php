<?php

return array (
  'new_message' => 'New Message',
  'sent_messages' => 'Sent Messages',
  'all_event_attendees' => 'All event attendees',
  'attendees_with_ticket_type' => 'Attendees with ticket type',
  'before_send_message' => 'The attendee will be instructed to send any reply to :organiser',
  'content' => 'Message Content',
  'date' => 'date',
  'leave_blank_to_send_immediately' => 'Leave blank to send immediately',
  'message' => 'Message',
  'no_messages_for_event' => 'No messages for the event.',
  'schedule_send_time' => 'Schedule send time',
  'send_a_copy_to' => 'Send a copy to :organiser',
  'send_message' => 'Send Message',
  'send_to' => 'Send to',
  'subject' => 'Message Subject',
  'to' => 'To',
  'unsent' => 'Unsent',
);