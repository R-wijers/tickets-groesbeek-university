<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:24:53
*************************************************************************/

return array (
  'service_fee_fixed_price' => 'Feste Servicegebühr',
  'service_fee_fixed_price_help' => 'e.g: enter <b>1.25</b> for <b>:cur1.25</b>',
  'service_fee_fixed_price_placeholder' => '0.00',
  'organiser_fees' => 'Organiser Fees',
  'organiser_fees_text' => 'Dies sind optionale Gebühren die Sie zu den Kosten jedes Tickets hinzufügen künnen. Diese gebühren werden auf den Rechungen als <b>BUCHUNGSGEBÜHREN</b> erscheinen.',
  'service_fee_percentage' => 'Prozentuale Buchungsgebühren',
  'service_fee_percentage_help' => 'e.g: geben Sie <b>3.5</b> für <b>3.5%</b> ein',
  'service_fee_percentage_placeholder' => '0',
);
