<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:21:50 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'event_page_preview' => 'Evenementen pagina voorvertoon',
  //==================================== Translations ====================================//
  'background_options' => 'Achtergrond Options',
  'images_provided_by_pixabay' => 'Abeeldingen beschikbaar gesteld door <b>PixaBay.com</b>',
  'select_from_available_images' => 'Selecteer beschikbare afbeeldingen',
  'use_a_colour_for_the_background' => 'Gebruik een achtergrond kleur',
);