<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:07:35
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'scan_another_ticket' => 'Scan een ander Ticket',
  'scanning' => 'Scannen',
  //==================================== Translations ====================================//
  'attendees' => 'Bezoeker',
  'check_in' => 'Check in: :event',
  'email' => 'E-mail',
  'email_address' => 'E-mailadres',
  'event_attendees' => 'Evenement bezoeker',
  'first_name' => 'Voornaam',
  'last_name' => 'Achternaam',
  'name' => 'Volledige Naam',
  'ticket' => 'Ticket',
  'reference' => 'Referentie',
  'search_attendees' => 'Zoek bezoekers...',
  'send_invitation_n_ticket_to_attendee' => 'Verzend uitnodigingen en tickets naar de bezoekers.',
);
