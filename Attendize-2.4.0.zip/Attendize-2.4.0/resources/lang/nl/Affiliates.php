<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:14:11 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'affiliate_name' => 'Affiliate Naam',
  'affiliate_tracking' => 'Affiliate Tracking',
  'affiliate_tracking_text' => 'Krijg op een eenvoudige manier inzichtelijk wie er voor u verkopen genereerd. Creër simpelweg een doorverwijs link in het onderstaande kader en deel deze link met uw partner / marketeer.',
  'last_referral' => 'Laaste doorverwijzing',
  'no_affiliate_referrals_yet' => 'Nog geen doorverwijzingen',
  'sales_volume_generated' => 'Aantal gegenereerde verkopen',
  'ticket_sales_generated' => 'Aantal tickets verkocht',
  'visits_generated' => 'Aantal gegenereerde bezoekers',
);