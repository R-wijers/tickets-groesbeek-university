<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/16 08:41:39 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
  'information' => 'Information',
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Public\\ViewOrganiser\\Partials\\EventListingPanel.blade.php
  'tickets' => 'Billets',
  //==================================== Translations ====================================//
  'no_events' => 'Pas de :panel_title à afficher.',
  'organiser_dashboard' => 'Tableau de bord de l\'organisateur',
  'past_events' => 'Événements passés',
  'upcoming_events' => 'Événements à venir',
);
