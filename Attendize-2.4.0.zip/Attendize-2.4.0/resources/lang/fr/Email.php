<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/26 11:05:24 
*************************************************************************/

return array (
  //==================================== Translations ====================================//
  'attendize_register' => 'Merci de votre inscription à Attendize',
  'contact_organiser' => 'Vous pouvez contacter :organiser_name directement à <a href="mailto::organiser_email">:organiser_email</a>, ou en répondant à ce message.',
  'invite_user' => ':name vous a ajouté à un compte :app',
  'message_received_from_organiser' => "Vous avez reçu un message de :organiser_name en rapport avec l'événement :event_title.",
  'message_regarding_event' => 'Message au sujet de : :event',
  'organiser_copy' => '[Copie Organisateur]',
  'refund_from_name' => 'Vous avez reçu un remboursement de :name',
  'your_ticket_cancelled' => 'Votre billet a été annulé',
  'your_ticket_for_event' => 'Votre billet pour l\'événement :event',
    //================================== Obsolete strings ==================================//
  'LLH:obsolete' => 
  array (

  ),
);
