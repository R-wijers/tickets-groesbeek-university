<?php

return [
    'Excel_xls' => 'Excel (XLS)',
    'Excel_xlsx' => 'Excel (XLSX)',
    'csv' => 'CSV',
    'html' => 'HTML',
];