<?php

return [
    'attendize_register' => 'Grazie per esserti registrato su Attendize',
    'contact_organiser' => 'Puoi contattare :organiser_name direttamente via <a href="mailto::organiser_email">:organiser_email</a> o rispondendo a questa email.',
    'invite_user' => ':name ti ha aggiunto ad un account :app ',
    'message_received_from_organiser' => "Hai ricevuto un messaggio da :organiser_name per l'evento :event_title.",
    'message_regarding_event' => 'Messaggio relativo a :event',
    'organiser_copy' => '[Copia Organizzatore]',
    'refund_from_name' => 'Hai ricevuto un rimborso da :name',
    'your_ticket_cancelled' => 'Il biglietto è stato annullato',
    'your_ticket_for_event' => 'Il biglietto per l\'evento :event',
    'LLH:obsolete' =>
        [

        ],
];
