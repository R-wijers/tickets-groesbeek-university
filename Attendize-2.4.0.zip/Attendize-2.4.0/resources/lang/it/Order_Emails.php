<?php
return [
    'received_new_order'             => "Hai ricevuto un nuovo ordine per l'evento",
    'order_still_awaiting_payment'   => "Nota: il pagamento per questo ordine deve ancora essere processato.",
    'manage_order'                   => "Puoi gestire questo ordine visitando",
    'successful_order'               => "Il tuo ordine per l'evento <strong>:name</strong> è confermato.",
    'tickets_attached'               => "I tuoi biglietti sono allegati a questa mail. Puoi vedere tutte le informazioni relative al tuo ordine e scaricare i biglietti visitando:",
];