<?php

return [
    'scan_another_ticket' => 'Scansiona un altro biglietto',
    'scanning' => 'Scansione',
    'attendees' => 'I partecipanti',
    'check_in' => 'Check-in :event',
    'email' => 'E-mail',
    'email_address' => 'Indirizzo email',
    'event_attendees' => 'Evento Partecipanti,',
    'first_name' => 'Nome di battesimo',
    'last_name' => 'Cognome',
    'name' => 'Nome',
    'ticket' => 'Biglietto',
    'reference' => 'Riferimento',
    'search_attendees' => 'Cerca partecipanti...',
    'send_invitation_n_ticket_to_attendee' => 'Invia invito e biglietto per partecipante. ',
];
