<?php

return array(
    'attendize_register'      => 'Gracias por registrarte en Attendize',
    'contact_organiser' => 'Puede ponerse en contacto con :organiser_name directamente en <a href="mailto::organiser_email">:organiser_email</a>, o respondiendo a este correo electrónico.',
    'invite_user'             => ':name te ha añadido a la cuenta :app.',
    'message_received_from_organiser' => 'Ha recibido un mensaje de :organiser_name en relación al evento :event_title.',
    'message_regarding_event' => 'Mensaje con respecto a: :event',
    'organiser_copy'          => '[Copia del organizador]',
    'refund_from_name'        => 'Has recibido un reembolso de :name',
    'your_ticket_cancelled'   => 'Tu entrada ha sido cancelada',
    'your_ticket_for_event'   => 'Tu entrada para el evento :event',
    'LLH:obsolete'            => array(),
);
