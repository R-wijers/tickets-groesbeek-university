<?php

return array(
    'scan_another_ticket'                  => 'Escanear otra entrada',
    'scanning'                             => 'Escaneo',
    'attendees'                            => 'Asistentes',
    'check_in'                             => 'Registro de ingreso: :event',
    'email'                                => 'Correo electrónico',
    'email_address'                        => 'Dirección de correo electrónico',
    'event_attendees'                      => 'Asistentes al evento',
    'first_name'                           => 'Nombre',
    'last_name'                            => 'Apellidos',
    'name'                                 => 'Nombre',
    'ticket'                               => 'Entrada',
    'reference'                            => 'Referencia',
    'search_attendees'                     => 'Buscar asistentes....',
    'send_invitation_n_ticket_to_attendee' => 'Envía la invitación y la entrada al asistente.',
);
