<?php
return [
    'received_new_order'             => 'Ha recibido un nuevo pedido para el evento',
    'order_still_awaiting_payment'   => 'Nota: Este pedido todavía no ha sido pagado.',
    'manage_order'                   => 'Puede gestionar este pedido en',
    'successful_order'               => 'Se ha procesado el pedido para el evento <strong>:name</strong> correctamente.',
    'tickets_attached'               => 'Sus entradas se adjuntan a este correo electrónico. También puede ver los detalles de su pedido y descargar sus entradas en:',
];