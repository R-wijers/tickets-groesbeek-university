<?php

return array(
    'affiliate_name'             => 'Nombre del afiliado',
    'affiliate_tracking'         => 'Seguimiento de afiliados',
    'affiliate_tracking_text'    => 'Llevar un registro de quién está generando ventas para su evento es extremadamente fácil. Simplemente cree un enlace de referencia usando la caja de abajo y comparta el enlace con sus afiliados / promotores de eventos.',
    'last_referral'              => 'Último Referido',
    'no_affiliate_referrals_yet' => 'No hay referidos de afiliados todavía',
    'sales_volume_generated'     => 'Volumen de ventas generado',
    'ticket_sales_generated'     => 'Venta de entradas generada',
    'visits_generated'           => 'Visitas generadas',
);