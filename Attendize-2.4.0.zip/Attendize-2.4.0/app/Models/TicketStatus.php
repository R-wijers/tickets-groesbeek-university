<?php

namespace App\Models;

    /*
      Attendize.com   - Event Management & Ticketing
     */

/**
 * Description of TicketStatuses.
 *
 * @author Dave
 */
class TicketStatus extends \Illuminate\Database\Eloquent\Model
{
    public $timestamps = false;
}
