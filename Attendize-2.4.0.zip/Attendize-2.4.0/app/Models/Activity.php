<?php

namespace App\Models;

    /*
      Attendize.com   - Event Management & Ticketing
     */

/**
 * Description of Activity.
 *
 * @author Dave
 */
class Activity extends \Illuminate\Database\Eloquent\Model
{
    //put your code here.
}
